package lab4;

import java.util.ArrayList;

public class AlunosQuestoes {
	private ArrayList<Aluno> alunos;

	public AlunosQuestoes() {
		this.alunos = new ArrayList<Aluno>();
	}

	public ArrayList<Aluno> getAlunos() {
		return alunos;
	}
	
	@Override
	public String toString() {
		String saida = "Alunos:\n";
		for(int i = 0 ; i < this.alunos.size();i++) {
			saida += i+1 + ". " + alunos.get(i).toString() + "\n";
		}
		return saida;
	}

}