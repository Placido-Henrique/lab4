package lab4;

import java.util.HashSet;

/**
 * Um grupo de estudos que possui membros e um tema que o indentifica.
 * 
 * @author Plácido Henrique Araújo Vieira Lima.
 *
 */
public class GrupoDeEstudos {
	
	/**
	 * Tema que identifica o grupo.
	 */
	private String tema;
	/**
	 * Conjunto de Alunos que representa os membros do grupo.
	 */
	private HashSet<Aluno> membros;

	/**
	 * Construtor do grupo de estudos. Incializa o Hash Set de Alunos, e atribui o tema
	 * recebido ao grupo.
	 * 
	 * @param tema tema do grupo de estudos a ser criado.
	 */
	public GrupoDeEstudos(String tema) {
		this.tema = tema;
		this.membros = new HashSet<Aluno>();
	}
	
	/**
	 * Gera uma string que contém as informações referentes ao grupo.
	 * 
	 * @return uma string no formato:
	 * "Alunos do grupo 'NOME DO GRUPO':
	 *  * 'MATRICULA' - 'NOME' - 'CURSO
	 *  *(assim em diante com todos os membros do grupo)...  
	 */
	
	@Override
	public String toString(){
		String saida = "Alunos do grupo " + this.tema + ":\n"  ;
		
		for (Aluno membro : membros) {
			saida += "* " + membro.toString()+ "\n";
		}
		
		return saida;
	}
	
	/**
	 * Adiciona um Aluno ao grupo de estudos, especificamente no HashSet de Alunos.
	 * 
	 * @param membro Aluno que será adicionado aos membros do grupo.
	 */
	public void addAluno(Aluno membro) {
		this.membros.add(membro);
	}
	
	/**
	 * Identifica se o grupo em questão está vazio.
	 * 
	 * @return um valor booleano true se o grupo está vazio e false caso contrário.
	 */
	public boolean grupoVazio() {
		if (this.membros.isEmpty()) {
			return true;
		}
		return false;
	}

	/**
	 * Hash code para indentificar o grupo.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((membros == null) ? 0 : membros.hashCode());
		result = prime * result + ((tema == null) ? 0 : tema.hashCode());
		return result;
	}

	/**
	 * Equals personalizado para garantir que dois alunos são iguais.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GrupoDeEstudos other = (GrupoDeEstudos) obj;
		if (membros == null) {
			if (other.membros != null)
				return false;
		} else if (!membros.equals(other.membros))
			return false;
		if (tema == null) {
			if (other.tema != null)
				return false;
		} else if (!tema.equals(other.tema))
			return false;
		return true;
	}
}
	