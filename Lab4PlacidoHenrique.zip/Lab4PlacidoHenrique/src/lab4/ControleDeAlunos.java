package lab4;

import java.util.HashMap;

public class ControleDeAlunos {
	private HashMap<String,Aluno> alunos;

	public ControleDeAlunos() {
		this.alunos = new HashMap<>();
	}
	
	public HashMap<String, Aluno> getAlunos() {
		return this.alunos;
	}
	
	public void cadastraAluno(String nome, String matricula,String curso) {
		Aluno aluno =new Aluno(nome, matricula, curso);
		this.alunos.put(matricula,aluno);
	}
}


