package lab4;

public class Aluno {
	private String matricula;
	private String nome;
	private String curso;

	public Aluno(String nome, String matricula,String curso) {
		this.matricula = matricula;
		this.nome = nome;
		this.curso = curso;
	}
	
	@Override
	public String toString() {
		return matricula + " - " + nome + " - " + curso;
	}

}