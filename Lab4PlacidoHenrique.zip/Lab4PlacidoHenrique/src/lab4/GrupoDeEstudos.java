package lab4;

import java.util.HashSet;

public class GrupoDeEstudos {
	private String nome;
	private String tema;
	private HashSet<String> membros;

	public GrupoDeEstudos(String nome, String tema) {
		this.membros = new HashSet<String>();
	}
}
