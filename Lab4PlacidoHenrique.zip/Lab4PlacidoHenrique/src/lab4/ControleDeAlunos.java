package lab4;

import java.util.HashMap;
import java.util.HashSet;

public class ControleDeAlunos {
	private HashMap<String,Aluno> alunos;
	private HashMap<String,HashSet<Aluno>>grupos;

	public ControleDeAlunos() {
		this.alunos = new HashMap<>();
		this.grupos = new HashMap<>();
	}
	
	public HashMap<String, Aluno> getAlunos() {
		return this.alunos;
	}
	
	public void cadastraAluno(String nome, String matricula,String curso) {
		Aluno aluno =new Aluno(nome, matricula, curso);
		this.alunos.put(matricula,aluno);
	}
	
	public HashMap<String,HashSet<Aluno>> getGrupos() {
		return this.grupos;
	}
	
	public void cadastraGrupo(String tema) {
		GrupoDeEstudos grupo = new GrupoDeEstudos(tema);
	}
	
	public void alocaAlunoGrupo(String matricula,String tema) {
		this.grupos.get(tema).add(this.alunos.get(matricula));
		
	}
}

