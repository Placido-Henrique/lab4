package lab4;

public class Menu {
	private String menu;

	public Menu() {
		this.menu = "\n" + 
				"(C)adastrar Aluno\n" + 
				"(E)xibir Aluno\n" + 
				"(N)ovo Grupo\n" + 
				"(A)locar Aluno no Grupo e Imprimir Grupos\n" + 
				"(R)egistrar Aluno que Respondeu\n" + 
				"(I)mprimir Alunos que Responderam\n" + 
				"(O)ra, vamos fechar o programa!\n" + 
				"\n" + 
				"Opção> ";
	}
	
	public String getMenu() {
		return this.menu;
	}
}
