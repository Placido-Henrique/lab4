package lab4;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Ferramenta de gerenciamento de alunos com suporte para cadastrar alunos através de matrículas, aloca-lós
 * em grupos, e coloca-lós em uma lista de alunos que responderam questões.
 * 
 * @author Plácido Henrique Araújo Vieira Lima.
 */
public class ControleDeAlunos {
	/**
	 * Mapa de alunos, cujas senhas são suas respectivas matrículas. Representa o cadastro dos alunos dentro
	 * do controle de alunos. 
	 */
	private HashMap<String,Aluno> alunosMatriculados;
	/**
	 * Mapa de grupos de estudo, com a senha sendo seus respectivos temas. Representa os grupos cadastrados
	 * no controle.
	 */
	private HashMap<String,GrupoDeEstudos> grupos;
	/**
	 * Lista dos alunos que responderam as questões. 
	 */
	private ArrayList<Aluno> alunosQuestoes;

	/**
	 * Construtor do controle de alunos. Gera o HashMap de Matriculas(key) e Alunos(value), o HashMap de temas
	 * e grupos, e a ArrayList de Alunos. 
	 */
	public ControleDeAlunos() {
		this.alunosMatriculados = new HashMap<>();
		this.grupos = new HashMap<>();
		this.alunosQuestoes = new ArrayList<>();
	}
	
	/**
	 * Verifica se a String recebida é vazia ou é um valor nulo, jogando uma excessaão no sistema caso
	 * uma dessas condições seja verdadeira.
	 * 
	 * @param elemento elemento que será avaliado pelo método
	 * @throws NullPointerException
	 * @return Uma NullPointerException caso o elemento seja nulo, ou uma IllegalArgumentException
	 * caso a string avaliada seja vazia.
	 */
	public void checkException(String elemento) throws NullPointerException {
		if(elemento == null) {
			throw new NullPointerException("ELEMENTO NULO!");
		}
		else if (elemento.equals("")) {
			throw new IllegalArgumentException("SEM TEXTO!");
		}
	}
	
	/**
	 * Cria um aluno com os parâmetros recebidos e o cadastra no sistema, ao inserir-lo no HashMap de Alunos.
	 * @param nome nome do aluno cadastrado no sistema. Além disso verifica se a entrada é inválida e joga
	 * uma excessão conforme o checkException.
	 * 
	 * @param matricula matricula do aluno.
	 * @param curso curso do aluno.
	 */
	public void cadastraAluno(String nome, String matricula,String curso) {
		checkException(nome);
		checkException(matricula);
		checkException(curso);
		Aluno aluno =new Aluno(nome, matricula, curso);
		this.alunosMatriculados.put(matricula,aluno);
	}
	
	/**
	 * Imprime a representação em String do aluno correspondente a matrícula fornecida, se ela estiver
	 * cadastrada no sistema.
	 * 
	 * @param matricula matrícula do aluno que se deseja imprimir. 
	 * @return uma String no padrão " 'MATRICULA' - 'NOME' - 'CURSO'" ou "Aluno não cadastrado" se
	 * o aluno não estiver no sistema.
	 */
	public String imprimeAluno(String matricula) {
		if (!this.hasMatricula(matricula)) {
			return "\nAluno não cadastrado.";
		}
			
		return "\n" + this.aluno(matricula).toString();
	}
	
	/**
	 * Cadastra um grupo no sistema com o tema fornecido como parâmetro. Faz uso do checkException para
	 * barrar entradas inválidas.
	 * 
	 * @param tema tema do grupo que será criado.
	 */
	public void cadastraGrupo(String tema) {
		checkException(tema);
		this.grupos.put(tema.toUpperCase(), new GrupoDeEstudos(tema));
	}
	
	/**
	 * Aloca um aluno em grupo a partir de sua matrícula e do seu tema,respectivamente. Faz uso
	 * do checkException.
	 * 
	 * @param matricula matrícula do aluno que será alocado.
	 * @param tema tema do grupo em que o aluno será alocado.
	 */
	public void alocaAlunoGrupo(String matricula,String tema){
		checkException(matricula);
		checkException(tema);
		
		this.grupos.get(tema.toUpperCase()).addAluno(this.alunosMatriculados.get(matricula));
		
	}
	
	/**
	 * Imprime uma lista dos membros do grupo referente ao tema fornecido. Faz uso
	 * do checkException.
	 * 
	 * @param tema tema do grupo que será impresso.
	 * @return uma string no formato:
	 * "Alunos do grupo 'NOME DO GRUPO':
	 *  * 'MATRICULA' - 'NOME' - 'CURSO
	 *  *(assim em diante com todos os membros do grupo)...  
	 */
	public String imprimeGrupo(String tema) {
		checkException(tema);
		return this.grupos.get(tema.toUpperCase()).toString();
	}
	
	/**
	 * Verifica se o sistema possui a matrícula recebida como parâmetro.  Faz uso
	 * do checkException.
	 * 
	 * @param key matricula que será procurada no sistema
	 * @return true se a matricula está no sistema e false caso contrário.
	 */
	public boolean hasMatricula(String key) {
		checkException(key);
		if (this.alunosMatriculados.containsKey(key)) {
			return true;
		}
		return false;
	}
	
	/**
	 * Verifica se o sistema possui o tema de grupo recebido como parâmetro. Faz uso
	 * do checkException.
	 * 
	 * @param tema tema a ser buscado no sistema
	 * @return true se o sistema possuir o tema ou false caso contrário.
	 */
	public boolean hasGrupo(String tema) {
		checkException(tema);
		if (this.grupos.containsKey(tema.toUpperCase())) {
			return true;
		}
		return false;	
	}
	
	/**
	 * Retorna o grupo de estudos que corresponde ao tema recebido. Faz uso
	 * do checkException.
	 * 
	 * @param tema tema do grupo a ser recebido.
	 * @return o grupo correspondente ao tema
	 */
	public GrupoDeEstudos grupo(String tema) {
		checkException(tema);
		return this.grupos.get(tema.toUpperCase());
	}
	
	/**
	 * Retorna o Aluno que corresponde a matrícula recebida. Faz uso
	 * do checkException.
	 * 
	 * @param matricula do aluno a ser recebido
	 * @return o aluno que corresponde a matrícula.
	 */
	public Aluno aluno(String matricula) {
		checkException(matricula);
		
		return this.alunosMatriculados.get(matricula);
	}
	
	/**
	 * Retorna a lista de alunos que responderam as questões na ordem em que foram adiconados, e com
	 * possibilidade de repetição.
	 * 
	 * @return uma string no formato:
	 * "Alunos:
	 * 1. 'MATRICULA' - 'NOME' - 'CURSO'
	 * (Assim em diante...)
	 */
	public String listaAlunosQuestoes() {
		String saida = "Alunos:\n";
		for(int i = 0 ; i < this.alunosQuestoes.size();i++) {
			saida +=  i+1 + ". " + alunosQuestoes.get(i).toString() + "\n";
		}
		return saida;
	}
	
	/**
	 * Adiciona um aluno a lista de alunos que responderam as questões
	 * 
	 * @param aluno o aluno que será adicionado na lista.
	 */
	public void adicionaAlunoQuestoes(Aluno aluno) {
		this.alunosQuestoes.add(aluno);
	}
	
	/**
	 * Verifica se a lista de alunos que responderam as questões está vazia.
	 * 
	 * @return true se a lista estiver vazia e false caso contrário.
	 */
	public boolean listaVazia() {
		if (this.alunosQuestoes.isEmpty()) {
			return true;
		}
		return false;
	}
	
}

