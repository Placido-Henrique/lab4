package lab4;

import java.util.ArrayList;

public class AlunosQuestoes {
	private ArrayList <String> alunos;

	public AlunosQuestoes() {
		this.alunos = new ArrayList <String> ();
	}

}