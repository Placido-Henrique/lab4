package lab4;

import java.util.ArrayList;
import java.util.HashMap;

public class ControleDeAlunos {
	private HashMap<String,Aluno> alunosMatriculados;
	private HashMap<String,GrupoDeEstudos> grupos;
	private ArrayList<Aluno> alunosQuestoes;

	public void checkNull(String elemento) throws NullPointerException {
		if ( elemento.equals("")) {
			throw new IllegalArgumentException("SEM TEXTO!");
		}
		else if(elemento == null) {
			throw new NullPointerException();
		}
	}
	
	public ControleDeAlunos() {
		this.alunosMatriculados = new HashMap<>();
		this.grupos = new HashMap<>();
		this.alunosQuestoes = new ArrayList<Aluno>();
	}
	
	public void cadastraAluno(String nome, String matricula,String curso) {
		checkNull(nome);
		checkNull(matricula);
		checkNull(curso);
		Aluno aluno =new Aluno(nome, matricula, curso);
		this.alunosMatriculados.put(matricula,aluno);
	}
	
	public void cadastraGrupo(String tema) {
		checkNull(tema);
		this.grupos.put(tema.toUpperCase(), new GrupoDeEstudos(tema));
	}
	
	public void alocaAlunoGrupo(String matricula,String tema){
		checkNull(matricula);
		checkNull(tema);
		
		this.grupos.get(tema.toUpperCase()).addAluno(this.alunosMatriculados.get(matricula));
		
	}
	
	public String imprimeGrupo(String tema) {
		checkNull(tema);
		return this.grupos.get(tema.toUpperCase()).toString();
	}
	
	public boolean hasMatricula(String key) {
		checkNull(key);
		if (this.alunosMatriculados.containsKey(key)) {
			return true;
		}
		return false;
	}
	
	public boolean hasGrupo(String key) {
		checkNull(key);
		if (this.grupos.containsKey(key.toUpperCase())) {
			return true;
		}
		return false;	
	}
	
	public GrupoDeEstudos grupo(String tema) {
		checkNull(tema);
		return this.grupos.get(tema.toUpperCase());
	}
	
	public Aluno aluno(String matricula) {
		checkNull(matricula);
		return this.alunosMatriculados.get(matricula);
	}
	
	public String listaAlunosQuestoes() {
		String saida = "Alunos:\n";
		for(int i = 0 ; i < this.alunosQuestoes.size();i++) {
			saida += i+1 + ". " + alunosQuestoes.get(i).toString() + "\n";
		}
		return saida;
	}
	
	public void adicionaAlunoQuestoes(Aluno aluno) {
		this.alunosQuestoes.add(aluno);
	}
	
	public boolean listaVazia() {
		if (this.alunosQuestoes.isEmpty()) {
			return true;
		}
		return false;
	}
	
}

