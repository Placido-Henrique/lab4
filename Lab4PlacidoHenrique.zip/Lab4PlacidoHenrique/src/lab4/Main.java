package lab4;

import java.util.Scanner;

public class Main {
	private static Scanner sc = new Scanner(System.in);
	private static ControleDeAlunos controle = new ControleDeAlunos();
	

	public static String textoMenu() {
		return "(C)adastrar Aluno\n" + 
				"(E)xibir Aluno\n" + 
				"(N)ovo Grupo\n" + 
				"(A)locar Aluno no Grupo e Imprimir Grupos\n" + 
				"(R)egistrar Aluno que Respondeu\n" + 
				"(I)mprimir Alunos que Responderam\n" + 
				"(O)ra, vamos fechar o programa!\n" + 
				"\n" + 
				"Opção> ";
	}
	
	public static String Menu(String comando) {
		if (comando.equals("C")) {
			System.out.print("Matrícula: ");
			String matricula= sc.nextLine();
			
			if (controle.hasMatricula(matricula)) {
				return "MATRÍCULA JÁ CADASTRADA!";
			
			}
			else {
			
			System.out.print("Nome: ");
			String nome = sc.nextLine();
			
			System.out.print("Curso: ");
			String curso = sc.nextLine();
			
			controle.cadastraAluno(nome, matricula, curso);
			return "CADASTRO REALIZADO!";
			}
		
		}
		
		
	}
	
	public static void main(String args[])  {
		String option;
		String acao;
		 
		do {
			textoMenu();
			option = sc.nextLine();
			option.toLowerCase();
			
			switch(option) {
			
			case "c":
				System.out.print("Matrícula: ");
				String matricula= sc.nextLine();
				
				if (controle.hasMatricula(matricula)) {
					System.out.println("MATRÍCULA JÁ CADASTRADA!");
					break;
				}
				
				System.out.print("Nome: ");
				String nome = sc.nextLine();
				
				System.out.print("Curso: ");
				String curso = sc.nextLine();
				
				controle.cadastraAluno(nome, matricula, curso);
				System.out.println("CADASTRO REALIZADO!");
				break;
			
				
			case "e":
				
				System.out.print("Matrícula: ");
				String key = sc.nextLine();
					
				if (!controle.hasMatricula(key)) {
					System.out.println("\nAluno não cadastrado.");
					break;
				}
				
				System.out.println("\n" + controle.aluno(key).toString());
				break;
				
				
			case "n":
				System.out.print("Grupo: ");
				String tema = sc.nextLine();
				
				if (controle.hasGrupo(tema)) {
					System.out.println("GRUPO JÁ CADASTRADO!");
					break;
				}
				
				controle.cadastraGrupo(tema);
				System.out.println("CADASTRO REALIZADO!");
				break;
				
				
			case "a":
				do {
					System.out.print("(A)locar Aluno ou (I)mprimir Grupo? ");
					acao = sc.nextLine();
					acao.toLowerCase();
					
					switch(acao) {
					
					case "a":
						System.out.print("Matrícula: ");
						String matriculaAlocar = sc.nextLine();
						
						controle.checkNull(matriculaAlocar);
						if (!controle.hasMatricula(matriculaAlocar)) {
							System.out.println("Aluno não cadastrado.");
							break;
						}
					
						System.out.print("Grupo: ");
						String grupo = sc.nextLine();
						
						controle.checkNull(grupo);
						if (!controle.hasGrupo(grupo)) {
							System.out.println("Grupo não cadastrado.");
							break;
						}
						
						controle.alocaAlunoGrupo(matriculaAlocar, grupo);
						System.out.println("ALUNO ALOCADO!");
						break;
					
						
					case "i":
						System.out.print("Grupo: ");
						String grupoImprimir = sc.nextLine();
						
						if (!controle.hasGrupo(grupoImprimir)) {
							System.out.println("Grupo não cadastrado.");
							break;
						}
						
						if (controle.grupo(grupoImprimir).grupoVazio()) {
							System.out.println("Grupo vazio.");
							break;
						}
						
						System.out.print(controle.imprimeGrupo(grupoImprimir));
						break;
						
						
					default:
						System.out.println("OPÇÃO INVÁLIDA");
					}
					
				}while(!acao.equals("a") && !acao.equals("i"));
				
				break;
				
			case "r":
				System.out.print("Matrícula: ");
				String aluno = sc.nextLine();
				
				if (!controle.hasMatricula(aluno)) {
					System.out.println("Aluno não cadastrado.");
					break;
				}
				
				controle.adicionaAlunoQuestoes(controle.aluno(aluno));
				System.out.println("ALUNO REGISTRADO!");
				
				break;
				
			case "i":
				if (controle.listaVazia()) {
					System.out.println("Lista vazia.");
					break;
				}
				
				System.out.print(controle.listaAlunosQuestoes());
				break;
			
			case "o":
				break;
				
			default:
				System.out.println("OPÇÃO INVÁLIDA!");
				break;
			}
		}while (!option.equals("o"));
		sc.close();
	}
}