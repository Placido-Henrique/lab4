package lab4;

import java.util.Scanner;

public class Main {

	public static void main(String args[])  {
		Menu menu = new Menu();
		ControleDeAlunos controle = new ControleDeAlunos();
		Scanner sc = new Scanner(System.in);
		String option;
		String acao;
		 
		do {
			System.out.print(menu.getMenu());
			option = sc.nextLine();
			option.toLowerCase();
			
			switch(option) {
			case "c":
				
				System.out.print("Matrícula: ");
				String matricula= sc.nextLine();
				if (controle.getAlunos().containsKey(matricula)) {
					System.out.println("MATRÍCULA JÁ CADASTRADA!");
					break;
				}
				
				System.out.print("Nome: ");
				String nome = sc.nextLine();
				
				System.out.print("Curso: ");
				String curso = sc.nextLine();
				
				controle.cadastraAluno(nome, matricula, curso);
				System.out.println("CADASTRO REALIZADO!");
				break;
			
			case "e":
				
				System.out.print("Matrícula: ");
				String key = sc.nextLine();
				if (!controle.getAlunos().containsKey(key)) {
					System.out.println("Aluno não cadastrado.");
					break;
				}
				System.out.println(controle.getAlunos().get(key).toString());
				break;
				
			case "n":
				System.out.print("Grupo: ");
				String tema = sc.nextLine();
				tema.toUpperCase();
				
				if (controle.getGrupos().containsKey(tema)) {
					System.out.println("GRUPO JÁ CADASTRADO!");
					break;
				}
				
				controle.cadastraGrupo(tema);
				System.out.println("CADASTRO REALIZADO!");
				break;
				
			case "a":
				do {
					System.out.print("(A)locar Aluno ou (I)mprimir Grupo? ");
					acao = sc.nextLine();
					acao.toLowerCase();
					
					switch(acao) {
					case "a":
						System.out.print("Matrícula: ");
						String matAloca = sc.nextLine();
						if (!controle.getAlunos().containsKey(matAloca)) {
							System.out.println("Aluno não cadastrado.");
							break;
						}
						
						
						System.out.print("Grupo: ");
						String grupo = sc.nextLine();
						if (!controle.getGrupos().containsKey(grupo)) {
							System.out.println("Grupo não cadastrado.");
							break;
						}
						
						
						controle.alocaAlunoGrupo(matAloca, grupo);
						System.out.println("ALUNO ALOCADO");
						break;
					
					case "i":
						break;
						
					default:
						System.out.println("OPÇÃO INVÁLIDA");
					}
					
					
				}while(!acao.equals("a") || !acao.equals("i"));
				
				
				
				
				break;
				
			case "r":
				break;
				
			case "i":
				break;
				
			default:
				System.out.println("OPÇÃO INVÁLIDA!\n");
				break;
			}
		}while (!option.equals("o"));
	}
}