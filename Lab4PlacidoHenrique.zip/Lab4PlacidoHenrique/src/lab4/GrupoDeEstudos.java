package lab4;

import java.util.HashSet;

public class GrupoDeEstudos {
	
	private String tema;
	private HashSet<Aluno> membros;

	public GrupoDeEstudos(String tema) {
		this.tema = tema;
		this.membros = new HashSet<Aluno>();
	}
	
	public HashSet<Aluno> getMembros() {
		return this.membros;
	}
	
	@Override
	public String toString(){
		String saida = "Alunos do grupo " + this.tema + ":\n"  ;
		
		for (Aluno membro : membros) {
			saida += "* " + membro.toString()+ "\n";
		}
		
		return saida;
	}
	
	public void addAluno(Aluno membro) {
		this.membros.add(membro);
	}
	
	public boolean grupoVazio() {
		if (this.membros.isEmpty()) {
			return true;
		}
		return false;
	}
	
}
	