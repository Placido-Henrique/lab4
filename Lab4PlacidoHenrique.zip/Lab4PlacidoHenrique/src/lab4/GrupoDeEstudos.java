package lab4;

import java.util.HashSet;

public class GrupoDeEstudos {
	
	private String tema;
	private HashSet<Aluno> membros;

	public GrupoDeEstudos(String tema) {
		this.membros = new HashSet<Aluno>();
	}
}
	