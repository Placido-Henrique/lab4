package lab4Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import lab4.ControleDeAlunos;

class ControleDeAlunosTest {
	private ControleDeAlunos controleTeste;
	
	@BeforeEach
	public void criaTestes() {
		this.controleTeste= new ControleDeAlunos();
		controleTeste.cadastraAluno("Plácido Henrique", "1", "Computação");
		controleTeste.cadastraAluno("Camila Guedes", "2", "Nutrição");
		controleTeste.cadastraGrupo("namorados");
		controleTeste.alocaAlunoGrupo("1", "namorados");
		controleTeste.alocaAlunoGrupo("2","namorados");
		controleTeste.adicionaAlunoQuestoes(controleTeste.aluno("1"));
		controleTeste.adicionaAlunoQuestoes(controleTeste.aluno("2"));
		controleTeste.adicionaAlunoQuestoes(controleTeste.aluno("1"));
	}

	@Test
	public void testCheckExceptionVazio() {
		try {
			controleTeste.checkException("");
			fail("Era esperado exceção ao passar código inválido");
		}
		
		catch(IllegalArgumentException iae) {
		}
	}
	
	@Test
	public void testCheckExceptionNull() {
		try {
			controleTeste.checkException(null);
			fail("Era esperado exceção ao passar código nulo");
		}
		
		catch(NullPointerException npe) {
		}
	}

	@Test
	public void testCadastraAlunoNulo() {
		try {
			controleTeste.cadastraAluno(null, "1", null);
			fail("Era esperado exceção ao passar código nulo");
		}
		
		catch (NullPointerException npe) {
		  }
		}
	
	@Test
	public void testCadastraAlunoVazio() {
		try {
			controleTeste.cadastraAluno("", "1", "computação");
			fail("Era esperado exceção ao passar código nulo");
		}
		
		catch (IllegalArgumentException iae) {
		  }	
		}

	
	@Test
	public void testImprimeGrupo() {
		assertEquals("Alunos do grupo namorados:\n"
				+ "* 1 - Plácido Henrique - Computação\n"
				+ "* 2 - Camila Guedes - Nutrição\n" , controleTeste.imprimeGrupo("namorados"));
	}

	@Test
	public void testHasMatricula() {
		assertFalse(controleTeste.hasMatricula("3"));
		assertTrue(controleTeste.hasMatricula("1"));
	}

	@Test
	public void testHasGrupo() {
		assertTrue(controleTeste.hasGrupo("namorados"));
		assertFalse(controleTeste.hasGrupo("aleatorio"));
	}

	
	@Test
	public void testAluno() {
		assertEquals("1 - Plácido Henrique - Computação",controleTeste.aluno("1").toString());
	}

	@Test
	public void testListaAlunosQuestoes() {
		assertEquals("Alunos:\n"
				+ "1. 1 - Plácido Henrique - Computação\n"
				+ "2. 2 - Camila Guedes - Nutrição\n"
				+ "3. 1 - Plácido Henrique - Computação\n" , controleTeste.listaAlunosQuestoes());
	}

	@Test
	public void testListaVazia() {
		assertFalse(controleTeste.listaVazia());
	}

}
