package lab4;

import java.util.HashMap;

public class ControleDeAlunos {
	private HashMap<String,Aluno> alunos;
	private HashMap<String,GrupoDeEstudos> grupos;

	public void checkNull(String elemento) throws NullPointerException{
		if ( elemento.equals("")) {
			throw new NullPointerException("SEM TEXTO!");
		}
		else if(elemento == null) {
			throw new NullPointerException();
		}
	}
	
	public ControleDeAlunos() {
		this.alunos = new HashMap<>();
		this.grupos = new HashMap<>();
	}
	
	public HashMap<String, Aluno> getAlunos() {
		return this.alunos;
	}
	
	public void cadastraAluno(String nome, String matricula,String curso) throws NullPointerException {
		checkNull(nome);
		checkNull(matricula);
		checkNull(curso);
		Aluno aluno =new Aluno(nome, matricula, curso);
		this.alunos.put(matricula,aluno);
	}
	
	public HashMap <String, GrupoDeEstudos> getGrupos() {
		return this.grupos;
	}
	
	public void cadastraGrupo(String tema) throws NullPointerException {
		checkNull(tema);
		this.grupos.put(tema.toUpperCase(), new GrupoDeEstudos(tema));
	}
	
	public void alocaAlunoGrupo(String matricula,String tema) throws NullPointerException {
		checkNull(matricula);
		checkNull(tema);
		
		this.grupos.get(tema.toUpperCase()).getMembros().add(this.alunos.get(matricula));
		
	}
	
	public String imprimeGrupo(String tema) throws NullPointerException {
		checkNull(tema);
		return this.grupos.get(tema.toUpperCase()).toString();
	}
	
}

