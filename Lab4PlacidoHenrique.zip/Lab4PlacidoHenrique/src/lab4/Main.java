package lab4;

import java.util.Scanner;

public class Main {
	private static Scanner sc = new Scanner(System.in);
	private static ControleDeAlunos controle = new ControleDeAlunos();
	

	public static String textoMenu() {
		return  "\n" +
			    "(C)adastrar Aluno\n" + 
				"(E)xibir Aluno\n" + 
				"(N)ovo Grupo\n" + 
				"(A)locar Aluno no Grupo e Imprimir Grupos\n" + 
				"(R)egistrar Aluno que Respondeu\n" + 
				"(I)mprimir Alunos que Responderam\n" + 
				"(O)ra, vamos fechar o programa!\n" + 
				"\n" + 
				"Opção> ";
	}
	
	
	public static String cadastrarAluno() {
		
		System.out.print("Matrícula: ");
		String matricula= sc.nextLine();
			
		if (controle.hasMatricula(matricula)) {
			return "MATRÍCULA JÁ CADASTRADA!";
		}
			
		System.out.print("Nome: ");
		String nome = sc.nextLine();
		
		System.out.print("Curso: ");
		String curso = sc.nextLine();
			
		controle.cadastraAluno(nome, matricula, curso);
		return "CADASTRO REALIZADO!";
		}
	
	
	public static String exibirAluno() {

		System.out.print("Matrícula: ");
		String key = sc.nextLine();
				
		return controle.imprimeAluno(key);
	}
	
	
	public static String novoGrupo() {
		System.out.print("Grupo: ");
		String tema = sc.nextLine();
		
		if (controle.hasGrupo(tema)) {
			return "GRUPO JÁ CADASTRADO!";
		}
		
		controle.cadastraGrupo(tema);
		return "CADASTRO REALIZADO!";
	}
	
	
	public static String alocarAlunoNoGrupoEImprimirGrupos() {
		String acao;
		
		do {
			System.out.print("(A)locar Aluno ou (I)mprimir Grupo? ");
			acao = sc.nextLine();
			acao.toLowerCase();
			
			switch(acao) {
			
			case "a":
				return alocarAlunoNoGrupo();
				
			case "i":
				return imprimirGrupo();
				
			default:
				return "OPÇÃO INVÁLIDA";
			}
			
		}while(!acao.equals("a") && !acao.equals("i"));
	
	}
	
	
	public static String alocarAlunoNoGrupo() {
		System.out.print("Matrícula: ");
		String matriculaAlocar = sc.nextLine();
		
		controle.checkException(matriculaAlocar);
		if (!controle.hasMatricula(matriculaAlocar)) {
			return "Aluno não cadastrado.";
		}
	
		System.out.print("Grupo: ");
		String grupo = sc.nextLine();
		
		controle.checkException(grupo);
		if (!controle.hasGrupo(grupo)) {
			return "Grupo não cadastrado.";
		}
		
		controle.alocaAlunoGrupo(matriculaAlocar, grupo);
		return "ALUNO ALOCADO!";
	}
	
	
	public static String imprimirGrupo() {
		System.out.print("Grupo: ");
		String grupoImprimir = sc.nextLine();
		
		if (!controle.hasGrupo(grupoImprimir)) {
			return "Grupo não cadastrado.";
		}
		
		if (controle.grupo(grupoImprimir).grupoVazio()) {
			return "Grupo vazio.";
		}
		
		return controle.imprimeGrupo(grupoImprimir);
	}
	
	public static String registrarAlunoQueRespondeu() {
		System.out.print("Matrícula: ");
		String aluno = sc.nextLine();
		
		if (!controle.hasMatricula(aluno)) {
			return "Aluno não cadastrado.";
		}
		
		controle.adicionaAlunoQuestoes(controle.aluno(aluno));
		return "ALUNO REGISTRADO!";
	}
	
	
	public static String imprimirAlunosQueResponderam() {
		if (controle.listaVazia()) {
			return "Lista vazia.";
		}
		
		return controle.listaAlunosQuestoes();
	}
			
	
	public static void main(String args[])  {
		String option;

		do {
			System.out.print(textoMenu());
			option = sc.nextLine();
			option.toLowerCase();
			
			switch(option) {
			
			case "c":
				System.out.println(cadastrarAluno());
				break;
				
			case "e":
				System.out.println(exibirAluno());
				break;
				
			case "n":
				System.out.println(novoGrupo());
				break;
				
				
			case "a":
				System.out.println(alocarAlunoNoGrupoEImprimirGrupos());
				break;
				
			case "r":
				System.out.println(registrarAlunoQueRespondeu());
				break;
				
			case "i":
				System.out.println(imprimirAlunosQueResponderam());
			
			case "o":
				break;
				
			default:
				System.out.println("OPÇÃO INVÁLIDA!");
				break;
			}
		}while (!option.equals("o"));
		sc.close();
	}
}