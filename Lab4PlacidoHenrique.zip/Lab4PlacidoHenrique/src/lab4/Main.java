package lab4;

import java.util.Scanner;

public class Main {

	public static void main(String args[])  {
		Menu menu = new Menu();
		ControleDeAlunos controle = new ControleDeAlunos();
		Scanner sc = new Scanner(System.in);
		String option;
		 
		do {
			System.out.print(menu.getMenu());
			option = sc.nextLine();
			option.toLowerCase();
			
			switch(option) {
			case "c":
				
				System.out.print("Matrícula: ");
				String matricula= sc.nextLine();
				if (controle.getAlunos().containsKey(matricula)) {
					System.out.println("MATRÍCULA JÁ CADASTRADA!");
					break;
				}
				
				System.out.print("Nome: ");
				String nome = sc.nextLine();
				
				System.out.print("Curso: ");
				String curso = sc.nextLine();
				
				controle.cadastraAluno(nome, matricula, curso);
				System.out.println("CADASTRO REALIZADO!");
				break;
			
			case "e":
				
				System.out.print("Matrícula: ");
				String key = sc.nextLine();
				if (!controle.getAlunos().containsKey(key)) {
					System.out.println("Aluno não cadastrado.");
					break;
				}
				System.out.println(controle.getAlunos().get(key).toString());
				break;
				
			case "n":
				break;
				
			case "a":
				break;
				
			case "r":
				break;
				
			case "i":
				break;
				
			default:
				System.out.println("OPÇÃO INVÁLIDA!\n");
				break;
			}
		}while (!option.equals("o"));
	}
}
